const GreetingCard = ({ title, message }) => {
    return (
      <div style={{ 
          border: "1px solid #ddd", 
          borderRadius: "8px", 
          padding: "15px", 
          margin: "10px", 
          maxWidth: "300px", 
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" 
      }}>
        <h2 style={{ fontSize: "1.5em", marginBottom: "10px" }}>{title}</h2>
        <p style={{ color: "#555" }}>{message}</p>
      </div>
    );
  };
  
  export default GreetingCard;
  