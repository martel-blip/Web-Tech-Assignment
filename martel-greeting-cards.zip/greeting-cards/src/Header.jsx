const Header = () => {
    return (
      <header style={{ 
        textAlign: "center", 
        padding: "20px",  // Increased padding
        backgroundColor: "#2196F3", // Changed background color
        color: "white", 
        fontSize: "2em", // Increased font size
        fontWeight: "bold", // Bold text
      }}>
        <h1>Welcome to Greeting Cards</h1>
      </header>
    );
  };
  
  export default Header;
  
  